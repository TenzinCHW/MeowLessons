# Import eBot and time module
from eBot import eBot
from time import sleep

def forward(speed, duration):
    # Write your code here
    pass

ebot = eBot.eBot() # create an eBot object
ebot.connect() # connect to the eBot via Bluetooth

############### Start writing your code here ################ 


########################## end ############################## 

ebot.disconnect() # disconnect the Bluetooth communication
